"""Tests for CLI launcher argument parsing and server creation."""
import argparse
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.request
import app


class CLITests(unittest.TestCase):
    def test_argument_parser_defaults(self):
        """Verify argument parser has correct defaults."""
        parser = argparse.ArgumentParser()
        parser.add_argument('--host', default='127.0.0.1')
        parser.add_argument('--port', type=int, default=8080)
        args = parser.parse_args([])
        self.assertEqual(args.host, '127.0.0.1')
        self.assertEqual(args.port, 8080)

    def test_argument_parser_custom_values(self):
        """Verify argument parser accepts custom host and port."""
        parser = argparse.ArgumentParser()
        parser.add_argument('--host', default='127.0.0.1')
        parser.add_argument('--port', type=int, default=8080)
        args = parser.parse_args(['--host', '0.0.0.0', '--port', '9000'])
        self.assertEqual(args.host, '0.0.0.0')
        self.assertEqual(args.port, 9000)

    def test_create_server_returns_threading_http_server(self):
        """Verify create_server returns a ThreadingHTTPServer instance."""
        from http.server import ThreadingHTTPServer
        previous = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            os.chdir(directory)
            server = None
            try:
                server = app.create_server('127.0.0.1', 0)
                self.assertIsInstance(server, ThreadingHTTPServer)
                self.assertEqual(server.server_address[0], '127.0.0.1')
                self.assertGreater(server.server_address[1], 0)
            finally:
                if server:
                    server.server_close()
                os.chdir(previous)

    def test_server_handles_concurrent_requests(self):
        """Verify ThreadingHTTPServer can handle concurrent requests."""
        previous = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            os.chdir(directory)
            server = None
            try:
                server = app.create_server('127.0.0.1', 0)
                worker = threading.Thread(target=server.serve_forever, daemon=True)
                worker.start()
                base = f'http://127.0.0.1:{server.server_address[1]}'
                
                # Make multiple concurrent requests
                import concurrent.futures
                def fetch_health():
                    with urllib.request.urlopen(base + '/health', timeout=3) as resp:
                        return json.load(resp)['status']
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                    futures = [executor.submit(fetch_health) for _ in range(20)]
                    results = [f.result() for f in concurrent.futures.as_completed(futures)]
                
                self.assertTrue(all(r == 'ok' for r in results))
            finally:
                if server:
                    server.shutdown()
                    server.server_close()
                    worker.join(3)
                os.chdir(previous)

    def test_server_binds_to_specified_host_port(self):
        """Verify server binds to the specified host and port."""
        previous = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            os.chdir(directory)
            server = None
            try:
                server = app.create_server('127.0.0.1', 0)
                host, port = server.server_address
                self.assertEqual(host, '127.0.0.1')
                self.assertGreater(port, 0)
                
                worker = threading.Thread(target=server.serve_forever, daemon=True)
                worker.start()
                
                with urllib.request.urlopen(f'http://{host}:{port}/health', timeout=3) as resp:
                    self.assertEqual(resp.status, 200)
                    self.assertEqual(json.load(resp)['status'], 'ok')
            finally:
                if server:
                    server.shutdown()
                    server.server_close()
                    worker.join(3)
                os.chdir(previous)


if __name__ == '__main__':
    unittest.main()
