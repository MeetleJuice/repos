"""Integration tests for REST API endpoints and server persistence."""
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from app import create_server


def request_json(url, method='GET', payload=None):
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    headers = {'Content-Type': 'application/json'} if payload is not None else {}
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            body = resp.read().decode('utf-8')
            return resp.status, json.loads(body) if body else None
    except urllib.error.HTTPError as exc:
        body = exc.read().decode('utf-8')
        return exc.code, json.loads(body) if body else None


class RestApiTests(unittest.TestCase):
    def setUp(self):
        self.prev_dir = Path.cwd()
        self.temp_dir = tempfile.TemporaryDirectory()
        os.chdir(self.temp_dir.name)
        self.server = create_server('127.0.0.1', 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f'http://127.0.0.1:{self.server.server_address[1]}'

    def tearDown(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(3)
        os.chdir(self.prev_dir)
        self.temp_dir.cleanup()

    def test_full_project_crud_and_summary_flow(self):
        # Initial summary
        status, summary = request_json(f'{self.base_url}/api/summary')
        self.assertEqual(status, 200)
        self.assertEqual(summary, {'planned': 0, 'active': 0, 'completed': 0, 'total': 0})

        # Create project 1 (planned)
        status, p1 = request_json(
            f'{self.base_url}/api/projects',
            method='POST',
            payload={'name': 'Portfolio Redesign', 'description': 'Revamp personal site', 'status': 'planned', 'deadline': '2025-12-31'},
        )
        self.assertEqual(status, 201)
        self.assertEqual(p1['name'], 'Portfolio Redesign')
        self.assertEqual(p1['status'], 'planned')
        self.assertEqual(p1['id'], 1)

        # Create project 2 (active)
        status, p2 = request_json(
            f'{self.base_url}/api/projects',
            method='POST',
            payload={'name': 'API Service', 'description': 'Lightweight web service', 'status': 'active', 'deadline': '2025-06-30'},
        )
        self.assertEqual(status, 201)
        self.assertEqual(p2['name'], 'API Service')
        self.assertEqual(p2['status'], 'active')

        # Verify summary counts
        status, summary = request_json(f'{self.base_url}/api/summary')
        self.assertEqual(status, 200)
        self.assertEqual(summary, {'planned': 1, 'active': 1, 'completed': 0, 'total': 2})

        # Fetch single project
        status, fetched_p1 = request_json(f'{self.base_url}/api/projects/1')
        self.assertEqual(status, 200)
        self.assertEqual(fetched_p1['id'], 1)
        self.assertEqual(fetched_p1['name'], 'Portfolio Redesign')

        # Search by query
        status, search_results = request_json(f'{self.base_url}/api/projects?q=Portfolio')
        self.assertEqual(status, 200)
        self.assertEqual(len(search_results), 1)
        self.assertEqual(search_results[0]['name'], 'Portfolio Redesign')

        # Filter by status
        status, filtered_results = request_json(f'{self.base_url}/api/projects?status=active')
        self.assertEqual(status, 200)
        self.assertEqual(len(filtered_results), 1)
        self.assertEqual(filtered_results[0]['name'], 'API Service')

        # Update project 1 to completed
        status, updated_p1 = request_json(
            f'{self.base_url}/api/projects/1',
            method='PUT',
            payload={'name': 'Portfolio Redesign v2', 'description': 'Updated design brief', 'status': 'completed', 'deadline': '2025-11-15'},
        )
        self.assertEqual(status, 200)
        self.assertEqual(updated_p1['id'], 1)
        self.assertEqual(updated_p1['name'], 'Portfolio Redesign v2')
        self.assertEqual(updated_p1['status'], 'completed')

        # Summary after update
        status, summary = request_json(f'{self.base_url}/api/summary')
        self.assertEqual(status, 200)
        self.assertEqual(summary, {'planned': 0, 'active': 1, 'completed': 1, 'total': 2})

        # Delete project 1
        status, del_resp = request_json(f'{self.base_url}/api/projects/1', method='DELETE')
        self.assertEqual(status, 200)
        self.assertEqual(del_resp, {'success': True})

        # Fetch deleted project returns 404
        status, err_resp = request_json(f'{self.base_url}/api/projects/1')
        self.assertEqual(status, 404)

        # Summary after delete
        status, summary = request_json(f'{self.base_url}/api/summary')
        self.assertEqual(status, 200)
        self.assertEqual(summary, {'planned': 0, 'active': 1, 'completed': 0, 'total': 1})

    def test_persistence_across_restart(self):
        request_json(
            f'{self.base_url}/api/projects',
            method='POST',
            payload={'name': 'Persistent Project', 'status': 'active'},
        )
        # Restart server instance
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(3)

        self.server = create_server('127.0.0.1', 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f'http://127.0.0.1:{self.server.server_address[1]}'

        status, fetched = request_json(f'{self.base_url}/api/projects/1')
        self.assertEqual(status, 200)
        self.assertEqual(fetched['name'], 'Persistent Project')
        self.assertEqual(fetched['status'], 'active')


if __name__ == '__main__':
    unittest.main()
