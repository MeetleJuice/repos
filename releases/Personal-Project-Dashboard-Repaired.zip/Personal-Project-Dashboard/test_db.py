"""Database persistence against the real implementation."""
import tempfile
from pathlib import Path
import unittest
import db

class DatabaseTests(unittest.TestCase):
    def test_persistence_and_combined_filter(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / 'projects.db')
            db.init_db(path)
            item = db.create_project({'name':'Saved project','status':'active'}, db_path=path)
            db.init_db(path)
            self.assertEqual(db.get_project(item['id'], db_path=path)['name'], 'Saved project')
            self.assertEqual(len(db.list_projects(q='Saved',status='active',db_path=path)),1)
            self.assertEqual(db.list_projects(q='Saved',status='completed',db_path=path),[])
