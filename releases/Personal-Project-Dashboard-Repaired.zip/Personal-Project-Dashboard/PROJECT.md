# Personal Project Dashboard

A clean, self-contained personal project dashboard built with Python's standard library and SQLite, featuring full CRUD, status summaries, search, filtering, and a dark-blue themed responsive UI.

## Approved features

- Project management: create, edit, and delete projects with name, description, status (planned, active, completed), and optional deadline
- Search and filtering: real-time search by project name and filtering by status
- Summary statistics: real-time dashboard counts for planned, active, and completed projects
- Responsive dark-themed UI and SQLite persistence across server restarts

## Architecture and execution contract

Python 3.11+, standard library only. app.py exposes create_server(host, port), /health and a browser interface. SQLite/JSON data stays local. No external services or package installation.

## Build order

1. Set up SQLite database layer and project models — Implement db.py with SQLite table creation ('projects' table with id, name, description, status, deadline, created_at, updated_at), database connection helper, and CRUD query functions including get_by_id, status summary counts, and search/filter queries.
2. Implement REST API endpoints in app.py — Create HTTP request handlers for GET /api/projects (with optional 'q' and 'status' query parameters), GET /api/projects/<id>, POST /api/projects, PUT /api/projects/<id>, DELETE /api/projects/<id>, and GET /api/summary. Ensure appropriate status codes (200, 201, 404), JSON serialization, and error handling.
3. Build the responsive dark-themed browser interface — Implement the frontend HTML/CSS/JS served at GET /. Design with a dark background (#0f172a / #1e293b), vibrant blue accents (#3b82f6), modal/inline forms for create and edit, live search input, status filter buttons, project cards with status tags, and KPI summary counters.
4. Add integration test suite and verify CLI launcher — Provide automated unittest tests verifying project creation, individual project retrieval (GET /api/projects/<id>), updates, status filtering, name search, deletion, summary calculations, and SQLite persistence across simulated restarts.

Tasks run sequentially. Later tasks build on saved files; checkpoints preserve previous versions.

## Acceptance criteria

- Health check: GET /health → HTTP 200
- Dashboard UI served with dark theme assets: GET / → HTTP 200
- Create a new planned project: POST /api/projects → HTTP 201
- Create a second active project: POST /api/projects → HTTP 201
- Verify summary counts reflect added projects: GET /api/summary → HTTP 200
- Search project by name query: GET /api/projects?q=Portfolio → HTTP 200
- Filter projects by active status: GET /api/projects?status=active → HTTP 200
- Update project details and status: PUT /api/projects/1 → HTTP 200
- Confirm updated summary counts: GET /api/summary → HTTP 200
- Verify data persistence after server restart: GET /api/projects/1 → HTTP 200
- Delete a project: DELETE /api/projects/1 → HTTP 200
- Verify summary counts after deletion: GET /api/summary → HTTP 200

# Manual acceptance checks

These are user observations, not automated verification. Test the downloaded app.

## 1. Theme styling and responsive layout verification

1. Open http://localhost:8000 in a browser window
2. Verify dark slate background with blue buttons and cards
3. Resize browser window to mobile width (around 375px) and verify summary cards and project grid wrap cleanly

Expected: Dark theme with blue accents renders correctly with no horizontal overflow or misaligned cards

## 2. Interactive project creation and modal workflow

1. Click the '+ New Project' button to open the project dialog
2. Enter project name, description, choose status 'Planned', set an optional deadline, and submit
3. Observe the project list and top summary counts

Expected: The dialog closes, the new project appears in the card list, and the 'Planned' counter increments by 1

## 3. Interactive search and status filtering

1. Type partial text into the search input box
2. Verify project cards filter instantly matching the title
3. Click 'Active' status filter button
4. Verify only active projects matching the query remain visible

Expected: Project list updates dynamically without page reloads

## 4. Edit and delete project interactions

1. Click the 'Edit' button on an existing project card
2. Change status from 'Active' to 'Completed' and save
3. Verify card status badge turns green/blue and summary counts update
4. Click 'Delete' on the project card and confirm the prompt

Expected: The project card is removed from the screen and summary totals update immediately


## Scope boundaries

- User authentication and multi-user accounts
- External database engines or ORMs
- Third-party CSS or JavaScript frameworks
- Email notifications and cloud syncing

## Known considerations

- Date parsing and validation across browser formats without third-party libraries
- Thread-safety and connection handling with SQLite in Python's standard http.server

Verification evidence is in BUILD-REPORT.json after export. A passing report covers the executed checks; it is not a guarantee of every possible behavior.

## Frozen proposal

```json
{
  "title": "Personal Project Dashboard",
  "app_kind": "server",
  "summary": "A clean, self-contained personal project dashboard built with Python's standard library and SQLite, featuring full CRUD, status summaries, search, filtering, and a dark-blue themed responsive UI.",
  "features": [
    "Project management: create, edit, and delete projects with name, description, status (planned, active, completed), and optional deadline",
    "Search and filtering: real-time search by project name and filtering by status",
    "Summary statistics: real-time dashboard counts for planned, active, and completed projects",
    "Responsive dark-themed UI and SQLite persistence across server restarts"
  ],
  "out_of_scope": [
    "User authentication and multi-user accounts",
    "External database engines or ORMs",
    "Third-party CSS or JavaScript frameworks",
    "Email notifications and cloud syncing"
  ],
  "risks": [
    "Date parsing and validation across browser formats without third-party libraries",
    "Thread-safety and connection handling with SQLite in Python's standard http.server"
  ],
  "tasks": [
    {
      "title": "Set up SQLite database layer and project models",
      "instructions": "Implement db.py with SQLite table creation ('projects' table with id, name, description, status, deadline, created_at, updated_at), database connection helper, and CRUD query functions including get_by_id, status summary counts, and search/filter queries.",
      "feature_indexes": [
        0,
        1,
        2,
        3
      ]
    },
    {
      "title": "Implement REST API endpoints in app.py",
      "instructions": "Create HTTP request handlers for GET /api/projects (with optional 'q' and 'status' query parameters), GET /api/projects/<id>, POST /api/projects, PUT /api/projects/<id>, DELETE /api/projects/<id>, and GET /api/summary. Ensure appropriate status codes (200, 201, 404), JSON serialization, and error handling.",
      "feature_indexes": [
        0,
        1,
        2
      ]
    },
    {
      "title": "Build the responsive dark-themed browser interface",
      "instructions": "Implement the frontend HTML/CSS/JS served at GET /. Design with a dark background (#0f172a / #1e293b), vibrant blue accents (#3b82f6), modal/inline forms for create and edit, live search input, status filter buttons, project cards with status tags, and KPI summary counters.",
      "feature_indexes": [
        0,
        1,
        2,
        3
      ]
    },
    {
      "title": "Add integration test suite and verify CLI launcher",
      "instructions": "Provide automated unittest tests verifying project creation, individual project retrieval (GET /api/projects/<id>), updates, status filtering, name search, deletion, summary calculations, and SQLite persistence across simulated restarts.",
      "feature_indexes": [
        0,
        1,
        2,
        3
      ]
    }
  ],
  "api_contracts": [
    {
      "method": "GET",
      "path": "/health",
      "status": 200,
      "response_kind": "object",
      "required_fields": [
        "status"
      ]
    },
    {
      "method": "GET",
      "path": "/",
      "status": 200,
      "response_kind": "text",
      "required_fields": []
    },
    {
      "method": "GET",
      "path": "/api/summary",
      "status": 200,
      "response_kind": "object",
      "required_fields": [
        "planned",
        "active",
        "completed",
        "total"
      ]
    },
    {
      "method": "GET",
      "path": "/api/projects",
      "status": 200,
      "response_kind": "array",
      "required_fields": []
    },
    {
      "method": "GET",
      "path": "/api/projects/1",
      "status": 200,
      "response_kind": "object",
      "required_fields": [
        "id",
        "name",
        "status"
      ]
    },
    {
      "method": "POST",
      "path": "/api/projects",
      "status": 201,
      "response_kind": "object",
      "required_fields": [
        "id",
        "name",
        "status"
      ]
    },
    {
      "method": "PUT",
      "path": "/api/projects/1",
      "status": 200,
      "response_kind": "object",
      "required_fields": [
        "id",
        "name",
        "status"
      ]
    },
    {
      "method": "DELETE",
      "path": "/api/projects/1",
      "status": 200,
      "response_kind": "object",
      "required_fields": [
        "success"
      ]
    }
  ],
  "checks": [
    {
      "name": "Health check",
      "method": "GET",
      "path": "/health",
      "status": 200,
      "json_contains": {
        "status": "ok"
      },
      "feature_indexes": [
        3
      ]
    },
    {
      "name": "Dashboard UI served with dark theme assets",
      "method": "GET",
      "path": "/",
      "status": 200,
      "contains": "Project Dashboard",
      "feature_indexes": [
        3
      ]
    },
    {
      "name": "Create a new planned project",
      "method": "POST",
      "path": "/api/projects",
      "body": {
        "name": "Portfolio Redesign",
        "description": "Revamp personal site with dark blue theme",
        "status": "planned",
        "deadline": "2025-12-31"
      },
      "status": 201,
      "json_contains": {
        "name": "Portfolio Redesign",
        "status": "planned"
      },
      "feature_indexes": [
        0
      ]
    },
    {
      "name": "Create a second active project",
      "method": "POST",
      "path": "/api/projects",
      "body": {
        "name": "API Service",
        "description": "Lightweight standard library web service",
        "status": "active",
        "deadline": "2025-06-30"
      },
      "status": 201,
      "json_contains": {
        "name": "API Service",
        "status": "active"
      },
      "feature_indexes": [
        0
      ]
    },
    {
      "name": "Verify summary counts reflect added projects",
      "method": "GET",
      "path": "/api/summary",
      "status": 200,
      "json_contains": {
        "planned": 1,
        "active": 1,
        "completed": 0,
        "total": 2
      },
      "feature_indexes": [
        2
      ]
    },
    {
      "name": "Search project by name query",
      "method": "GET",
      "path": "/api/projects?q=Portfolio",
      "status": 200,
      "json_contains": [
        {
          "name": "Portfolio Redesign"
        }
      ],
      "feature_indexes": [
        1
      ]
    },
    {
      "name": "Filter projects by active status",
      "method": "GET",
      "path": "/api/projects?status=active",
      "status": 200,
      "json_contains": [
        {
          "name": "API Service",
          "status": "active"
        }
      ],
      "feature_indexes": [
        1
      ]
    },
    {
      "name": "Update project details and status",
      "method": "PUT",
      "path": "/api/projects/1",
      "body": {
        "name": "Portfolio Redesign v2",
        "description": "Updated design brief",
        "status": "completed",
        "deadline": "2025-11-15"
      },
      "status": 200,
      "json_contains": {
        "id": 1,
        "name": "Portfolio Redesign v2",
        "status": "completed"
      },
      "feature_indexes": [
        0
      ]
    },
    {
      "name": "Confirm updated summary counts",
      "method": "GET",
      "path": "/api/summary",
      "status": 200,
      "json_contains": {
        "planned": 0,
        "active": 1,
        "completed": 1,
        "total": 2
      },
      "feature_indexes": [
        2
      ]
    },
    {
      "name": "Verify data persistence after server restart",
      "method": "GET",
      "path": "/api/projects/1",
      "restart_before": true,
      "status": 200,
      "json_contains": {
        "id": 1,
        "name": "Portfolio Redesign v2",
        "status": "completed"
      },
      "feature_indexes": [
        0,
        3
      ]
    },
    {
      "name": "Delete a project",
      "method": "DELETE",
      "path": "/api/projects/1",
      "status": 200,
      "json_contains": {
        "success": true
      },
      "feature_indexes": [
        0
      ]
    },
    {
      "name": "Verify summary counts after deletion",
      "method": "GET",
      "path": "/api/summary",
      "status": 200,
      "json_contains": {
        "planned": 0,
        "active": 1,
        "completed": 0,
        "total": 1
      },
      "feature_indexes": [
        0,
        2
      ]
    }
  ],
  "manual_checks": [
    {
      "name": "Theme styling and responsive layout verification",
      "steps": [
        "Open http://localhost:8000 in a browser window",
        "Verify dark slate background with blue buttons and cards",
        "Resize browser window to mobile width (around 375px) and verify summary cards and project grid wrap cleanly"
      ],
      "expected": "Dark theme with blue accents renders correctly with no horizontal overflow or misaligned cards",
      "feature_indexes": [
        3
      ]
    },
    {
      "name": "Interactive project creation and modal workflow",
      "steps": [
        "Click the '+ New Project' button to open the project dialog",
        "Enter project name, description, choose status 'Planned', set an optional deadline, and submit",
        "Observe the project list and top summary counts"
      ],
      "expected": "The dialog closes, the new project appears in the card list, and the 'Planned' counter increments by 1",
      "feature_indexes": [
        0,
        2
      ]
    },
    {
      "name": "Interactive search and status filtering",
      "steps": [
        "Type partial text into the search input box",
        "Verify project cards filter instantly matching the title",
        "Click 'Active' status filter button",
        "Verify only active projects matching the query remain visible"
      ],
      "expected": "Project list updates dynamically without page reloads",
      "feature_indexes": [
        1
      ]
    },
    {
      "name": "Edit and delete project interactions",
      "steps": [
        "Click the 'Edit' button on an existing project card",
        "Change status from 'Active' to 'Completed' and save",
        "Verify card status badge turns green/blue and summary counts update",
        "Click 'Delete' on the project card and confirm the prompt"
      ],
      "expected": "The project card is removed from the screen and summary totals update immediately",
      "feature_indexes": [
        0,
        2
      ]
    }
  ]
}
```
