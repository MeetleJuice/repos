"""Personal Project Dashboard server and API routes."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import urllib.parse
from db import (
    create_project,
    delete_project,
    get_project,
    get_summary,
    init_db,
    list_projects,
    update_project,
)

ASSETS = Path(__file__).resolve().parent
PROJECT_DETAIL_RE = re.compile(r"^/api/projects/(\d+)$")


def create_server(host='127.0.0.1', port=8080):
    init_db()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def reply(self, value, status=200, content_type='application/json; charset=utf-8'):
            content = value if isinstance(value, bytes) else json.dumps(value).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(content)

        def read_json_body(self):
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length == 0:
                return {}
            try:
                body = self.rfile.read(content_length).decode('utf-8')
                return json.loads(body)
            except Exception:
                return None

        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path

            if path == '/health':
                return self.reply({'status': 'ok'})

            if path == '/api/summary':
                return self.reply(get_summary())

            if path == '/api/projects':
                query = urllib.parse.parse_qs(parsed.query)
                q = query.get('q', [None])[0]
                status = query.get('status', [None])[0]
                return self.reply(list_projects(q=q, status=status))

            m = PROJECT_DETAIL_RE.match(path)
            if m:
                project_id = int(m.group(1))
                project = get_project(project_id)
                if project is None:
                    return self.reply({'error': 'Project not found'}, 404)
                return self.reply(project)

            assets = {
                '/': ('index.html', 'text/html; charset=utf-8'),
                '/style.css': ('style.css', 'text/css; charset=utf-8'),
                '/dashboard.js': ('dashboard.js', 'text/javascript; charset=utf-8'),
            }
            if path in assets:
                filename, content_type = assets[path]
                asset_path = ASSETS / filename
                if asset_path.exists():
                    return self.reply(asset_path.read_bytes(), content_type=content_type)

            return self.reply({'error': 'Not found'}, 404)

        def do_POST(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path

            if path == '/api/projects':
                data = self.read_json_body()
                if data is None or not isinstance(data, dict):
                    return self.reply({'error': 'Invalid JSON body'}, 400)
                try:
                    project = create_project(data)
                    return self.reply(project, 201)
                except ValueError as exc:
                    return self.reply({'error': str(exc)}, 400)

            return self.reply({'error': 'Not found'}, 404)

        def do_PUT(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path

            m = PROJECT_DETAIL_RE.match(path)
            if m:
                project_id = int(m.group(1))
                data = self.read_json_body()
                if data is None or not isinstance(data, dict):
                    return self.reply({'error': 'Invalid JSON body'}, 400)
                try:
                    project = update_project(project_id, data)
                    if project is None:
                        return self.reply({'error': 'Project not found'}, 404)
                    return self.reply(project, 200)
                except ValueError as exc:
                    return self.reply({'error': str(exc)}, 400)

            return self.reply({'error': 'Not found'}, 404)

        def do_DELETE(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path

            m = PROJECT_DETAIL_RE.match(path)
            if m:
                project_id = int(m.group(1))
                success = delete_project(project_id)
                if not success:
                    return self.reply({'error': 'Project not found'}, 404)
                return self.reply({'success': True}, 200)

            return self.reply({'error': 'Not found'}, 404)

    return ThreadingHTTPServer((host, port), Handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8080)
    args = parser.parse_args()
    create_server(args.host, args.port).serve_forever()
