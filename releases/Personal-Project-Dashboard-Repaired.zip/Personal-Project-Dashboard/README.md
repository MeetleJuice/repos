# Personal Project Dashboard

A clean, self-contained personal project dashboard built with Python's standard library and SQLite, featuring full CRUD, status summaries, search, filtering, and a dark-blue themed responsive UI.

Requires Python 3.11+. No third-party packages.

Run `python app.py --host 127.0.0.1 --port 8080`, then open http://127.0.0.1:8080.
On Windows you can double-click run.bat.

AI-generated code: review it before running. See PROJECT.md for the agreed scope and CHECKS.json for acceptance checks.
Passing checks is evidence of the tested behaviors, not a guarantee of all requirements.

The launch scripts wait for the app to become ready and open your browser. If port 8080 is busy, the launcher chooses another free port and prints the address. Keep its terminal open.
