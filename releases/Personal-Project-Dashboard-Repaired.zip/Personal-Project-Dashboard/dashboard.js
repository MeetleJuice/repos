'use strict';
const $ = id => document.getElementById(id);
let editing = null, sequence = 0;
async function request(path, method='GET', body) {
  const response = await fetch(path, {method, headers:body ? {'Content-Type':'application/json'} : {}, body:body ? JSON.stringify(body) : undefined});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed');
  return result;
}
function notify(error) { $('message').textContent = error.message; }
function openEditor(project=null) {
  editing = project?.id ?? null;
  $('modal-title').textContent = project ? 'Edit Project' : 'New Project';
  for (const key of ['name','description','deadline']) $(key).value = project?.[key] || '';
  $('status').value = project?.status || 'planned';
  $('editor').showModal();
}
async function refresh() {
  const version = ++sequence;
  const params = new URLSearchParams({q:$('search').value,status:$('filter').value});
  const [projects, summary] = await Promise.all([request('/api/projects?'+params), request('/api/summary')]);
  if (version !== sequence) return;
  for (const status of ['planned','active','completed']) $(status).textContent = summary[status];
  $('projects').replaceChildren();
  for (const project of projects) {
    const card = document.createElement('article'); card.className = 'project-card';
    const title = document.createElement('h2'); title.textContent = project.name;
    const description = document.createElement('p'); description.textContent = project.description;
    const status = document.createElement('span'); status.className='tag '+project.status; status.textContent=project.status;
    const deadline = document.createElement('p'); deadline.textContent=project.deadline ? 'Due '+project.deadline : 'No deadline';
    const edit = document.createElement('button'); edit.textContent='Edit'; edit.onclick=()=>openEditor(project);
    const remove = document.createElement('button'); remove.textContent='Delete'; remove.className='secondary'; remove.onclick=async()=>{
      if (!confirm('Delete this project?')) return;
      try { await request('/api/projects/'+project.id,'DELETE'); await refresh(); } catch(error) { notify(error); }
    };
    card.append(status,title,description,deadline,edit,remove); $('projects').append(card);
  }
  $('message').textContent=projects.length ? '' : 'No matching projects. Start something new.';
}
$('new').onclick=()=>openEditor(); $('cancel').onclick=()=>$('editor').close();
$('search').oninput=()=>refresh().catch(notify); $('filter').onchange=()=>refresh().catch(notify);
$('project-form').onsubmit=async event=>{
  event.preventDefault(); $('save').disabled=true;
  try {
    const body=Object.fromEntries(['name','description','status','deadline'].map(key=>[key,$(key).value]));
    await request(editing===null ? '/api/projects' : '/api/projects/'+editing, editing===null ? 'POST' : 'PUT', body);
    $('editor').close(); await refresh();
  } catch(error) { notify(error); } finally { $('save').disabled=false; }
};
refresh().catch(notify);
