"""API error behavior against the actual server."""
import unittest
import test_app as support
from test_app import request_json
from app import create_server

class ErrorTests(unittest.TestCase):
    setUp = support.RestApiTests.setUp
    tearDown = support.RestApiTests.tearDown
    def test_missing_project(self):
        for method in ['GET', 'DELETE']:
            status, body = request_json(self.base_url + '/api/projects/999999', method=method)
            self.assertEqual(status, 404)
        status, body = request_json(self.base_url + '/api/projects', method='POST', payload={'name':''})
        self.assertEqual(status, 400)
