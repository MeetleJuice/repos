# Repaired Personal Project Dashboard

Extract this ZIP into a new folder. On Windows, double-click run.bat. Python 3.11 or newer is required. No pip packages or API keys are needed. Keep the terminal open while using the app; Ctrl+C stops it.

The launcher opens the chosen local browser address automatically. Project data is stored in projects.db in this extracted folder. This export includes no personal database.

The invalid placeholder test files were replaced, browser markup and JavaScript rebuilt, SQLite connections closed reliably, and a test socket leak repaired. The original test_app.py and test_foundation.py are unchanged. BUILD-REPORT.original.json preserves the original failure report; BUILD-REPORT.json records recovery verification.

All 12 approved project HTTP checks plus the runner health/home checks passed, referenced assets passed, 10 unit/integration tests passed, a separate-process persistence restart passed, and the real browser interaction check passed. These automated observations do not replace your own manual acceptance review.

This is the dashboard app, not the Idea Foundry workbench. Keep their folders separate. The Foundry update does not automatically replace the project inside your existing workspace.
