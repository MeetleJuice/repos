"""SQLite database access layer and project model operations."""
from datetime import datetime, timezone
import sqlite3
from contextlib import contextmanager

DB_FILE = 'projects.db'
VALID_STATUSES = ('planned', 'active', 'completed')


@contextmanager
def get_connection(db_path=DB_FILE):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_db(db_path=DB_FILE):
    with get_connection(db_path) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'planned',
                deadline TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')
        conn.commit()


def row_to_dict(row):
    if row is None:
        return None
    return {
        'id': row['id'],
        'name': row['name'],
        'description': row['description'] or '',
        'status': row['status'],
        'deadline': row['deadline'] or '',
        'created_at': row['created_at'],
        'updated_at': row['updated_at'],
    }


def create_project(data, db_path=DB_FILE):
    name = (data.get('name') or '').strip()
    if not name:
        raise ValueError('Project name is required')
    description = (data.get('description') or '').strip()
    status = data.get('status', 'planned')
    if status not in VALID_STATUSES:
        status = 'planned'
    deadline = (data.get('deadline') or '').strip()
    now = datetime.now(timezone.utc).isoformat()

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            '''
            INSERT INTO projects (name, description, status, deadline, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ''',
            (name, description, status, deadline, now, now),
        )
        conn.commit()
        project_id = cursor.lastrowid
    return get_project(project_id, db_path=db_path)


def get_project(project_id, db_path=DB_FILE):
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM projects WHERE id = ?', (project_id,))
        row = cursor.fetchone()
        return row_to_dict(row)


def list_projects(q=None, status=None, db_path=DB_FILE):
    sql = 'SELECT * FROM projects WHERE 1=1'
    params = []
    if q:
        sql += ' AND (name LIKE ? OR description LIKE ?)'
        search_term = f'%{q.strip()}%'
        params.extend([search_term, search_term])
    if status and status in VALID_STATUSES:
        sql += ' AND status = ?'
        params.append(status)
    sql += ' ORDER BY id DESC'

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(sql, tuple(params))
        rows = cursor.fetchall()
        return [row_to_dict(row) for row in rows]


def update_project(project_id, data, db_path=DB_FILE):
    current = get_project(project_id, db_path=db_path)
    if not current:
        return None

    name = data.get('name')
    name = name.strip() if name is not None else current['name']
    if not name:
        raise ValueError('Project name cannot be empty')

    description = data.get('description')
    description = description.strip() if description is not None else current['description']

    status = data.get('status')
    if status is not None:
        if status not in VALID_STATUSES:
            status = current['status']
    else:
        status = current['status']

    deadline = data.get('deadline')
    deadline = deadline.strip() if deadline is not None else current['deadline']
    now = datetime.now(timezone.utc).isoformat()

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            '''
            UPDATE projects
            SET name = ?, description = ?, status = ?, deadline = ?, updated_at = ?
            WHERE id = ?
            ''',
            (name, description, status, deadline, now, project_id),
        )
        conn.commit()
    return get_project(project_id, db_path=db_path)


def delete_project(project_id, db_path=DB_FILE):
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('DELETE FROM projects WHERE id = ?', (project_id,))
        conn.commit()
        return cursor.rowcount > 0


def get_summary(db_path=DB_FILE):
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'planned' THEN 1 ELSE 0 END) as planned,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM projects
        ''')
        row = cursor.fetchone()
        return {
            'planned': row['planned'] or 0,
            'active': row['active'] or 0,
            'completed': row['completed'] or 0,
            'total': row['total'] or 0,
        }
