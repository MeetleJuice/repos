# Build tasks

1. Set up SQLite database layer and project models
   Implement db.py with SQLite table creation ('projects' table with id, name, description, status, deadline, created_at, updated_at), database connection helper, and CRUD query functions including get_by_id, status summary counts, and search/filter queries.
2. Implement REST API endpoints in app.py
   Create HTTP request handlers for GET /api/projects (with optional 'q' and 'status' query parameters), GET /api/projects/<id>, POST /api/projects, PUT /api/projects/<id>, DELETE /api/projects/<id>, and GET /api/summary. Ensure appropriate status codes (200, 201, 404), JSON serialization, and error handling.
3. Build the responsive dark-themed browser interface
   Implement the frontend HTML/CSS/JS served at GET /. Design with a dark background (#0f172a / #1e293b), vibrant blue accents (#3b82f6), modal/inline forms for create and edit, live search input, status filter buttons, project cards with status tags, and KPI summary counters.
4. Add integration test suite and verify CLI launcher
   Provide automated unittest tests verifying project creation, individual project retrieval (GET /api/projects/<id>), updates, status filtering, name search, deletion, summary calculations, and SQLite persistence across simulated restarts.