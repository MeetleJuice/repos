# Manual acceptance checks

These are user observations, not automated verification. Test the downloaded app.

## 1. Theme styling and responsive layout verification

1. Open http://localhost:8000 in a browser window
2. Verify dark slate background with blue buttons and cards
3. Resize browser window to mobile width (around 375px) and verify summary cards and project grid wrap cleanly

Expected: Dark theme with blue accents renders correctly with no horizontal overflow or misaligned cards

## 2. Interactive project creation and modal workflow

1. Click the '+ New Project' button to open the project dialog
2. Enter project name, description, choose status 'Planned', set an optional deadline, and submit
3. Observe the project list and top summary counts

Expected: The dialog closes, the new project appears in the card list, and the 'Planned' counter increments by 1

## 3. Interactive search and status filtering

1. Type partial text into the search input box
2. Verify project cards filter instantly matching the title
3. Click 'Active' status filter button
4. Verify only active projects matching the query remain visible

Expected: Project list updates dynamically without page reloads

## 4. Edit and delete project interactions

1. Click the 'Edit' button on an existing project card
2. Change status from 'Active' to 'Completed' and save
3. Verify card status badge turns green/blue and summary counts update
4. Click 'Delete' on the project card and confirm the prompt

Expected: The project card is removed from the screen and summary totals update immediately
